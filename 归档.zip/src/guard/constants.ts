export const jwtConstants = {
  secret: 'gasdfsovkjiorjweqiofn2134ljkhinu',
};
